function [calibpoints] = ETcalib

    %performs calibration and saves calibration points to file

global pname Calib;

%sets parameters for calibration
SetCalibParams; 
calibpoints = [];

%perform calibration routine
 %is always performed on primary display
disp('Starting Calibration workflow');
% Perform calibration
[calibpoints] = HandleCalibWorkflow(Calib);
disp('Calibration workflow stopped');

%write calibration points to file
% temp_table = struct2table(calibpoints);
% writetable(temp_table,'calibpoints.csv')
% saved as mat file --> manipulate to a flat format in R

if ~isempty(calibpoints)
    cd data
    save(strcat(pname,'_','calibpoints.mat'),'calibpoints');
    cd ..
else
    disp('No calibration points saved ... continue without calibration')
end

end